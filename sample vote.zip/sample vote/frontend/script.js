const app = document.getElementById('app');

// Fake database (for demo purposes)
const votedVoters = {};  // { voterId: true }

// Demo party list
const parties = [
  { id: 'partyA', name: 'Party A' },
  { id: 'partyB', name: 'Party B' },
  { id: 'partyC', name: 'Party C' }
];

function renderPage(page) {
  switch (page) {
    case 'home':
      app.innerHTML = `
      <div class="header">
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Emblem_of_India.svg/100px-Emblem_of_India.svg.png" alt="Government Logo" />
        <div class="links">
          <a href="#" id="admin-link">Admin</a>
        </div>
        <h1>Online Secure One Person One Vote System</h1>
      </div>
      <div class="main-content">
        <button id="vote-btn">Vote Casting</button>
      </div>
      `;
      document.getElementById('vote-btn').onclick = () => renderPage('details');
      document.getElementById('admin-link').onclick = () => alert('Admin Page (Not Implemented)');
      break;

    case 'details':
      app.innerHTML = `
        <div class="header">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Emblem_of_India.svg/100px-Emblem_of_India.svg.png" alt="Government Logo" />
          <h2>Voter Verification</h2>
        </div>
        <div class="main-content">
          <form id="details-form">
            <input type="text" id="voterid" placeholder="Voter ID" required />
            <input type="text" id="phone" placeholder="Phone Number" required />
            <button type="submit">Verify</button>
          </form>
          <div id="err-msg" style="color:red;margin-top:10px;"></div>
        </div>
      `;
      document.getElementById('details-form').onsubmit = (e) => {
        e.preventDefault();
        const voterId = document.getElementById('voterid').value.trim();
        const phone = document.getElementById('phone').value.trim();
        if (!voterId || !/^\d{10}$/.test(phone)) {
          document.getElementById('err-msg').innerText = 'Enter valid details.';
          return;
        }
        // One person, one vote check
        if (votedVoters[voterId]) {
          document.getElementById('err-msg').innerText = 'Vote already casted for this Voter ID.';
          return;
        }
        localStorage.setItem('currentVoter', JSON.stringify({ voterId, phone }));
        renderPage('iris');
      };
      break;

    case 'iris':
      app.innerHTML = `
        <div class="header">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Emblem_of_India.svg/100px-Emblem_of_India.svg.png" alt="Government Logo" />
          <h2>Iris Verification</h2>
        </div>
        <div class="main-content">
          <p>Look into the camera for iris scan (simulated).</p>
          <button id="iris-verify-btn">Verify (Demo)</button>
        </div>
      `;
      document.getElementById('iris-verify-btn').onclick = () => setTimeout(() => renderPage('parties'), 1000);
      break;

    case 'parties':
      app.innerHTML = `
        <div class="header">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Emblem_of_India.svg/100px-Emblem_of_India.svg.png" alt="Government Logo" />
          <h2>Select Your Party</h2>
        </div>
        <div class="main-content">
          <form id="party-form">
          ${parties.map(p =>
            `<button type="submit" class="party-choice" value="${p.id}">${p.name}</button>`
          ).join('')}
          </form>
        </div>
      `;
      document.querySelectorAll('.party-choice').forEach(btn => {
        btn.onclick = function(e) {
          e.preventDefault();
          const voter = JSON.parse(localStorage.getItem('currentVoter'));
          votedVoters[voter.voterId] = true; // Save vote (in-memory, demo only)
          localStorage.removeItem('currentVoter');
          renderPage('success');
        }
      });
      break;

    case 'success':
      app.innerHTML = `
        <div class="header">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Emblem_of_India.svg/100px-Emblem_of_India.svg.png" alt="Government Logo" />
          <h2>Thank You!</h2>
        </div>
        <div class="main-content">
          <p style="font-size:1.2em;color:green;font-weight:bold;">Your vote is successfully casted.</p>
          <p>Redirecting for the next voter...</p>
        </div>
      `;
      setTimeout(() => renderPage('home'), 10000);
      break;
  }
}

// Start at home
renderPage('home');
