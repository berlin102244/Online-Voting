const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
require('dotenv').config();

// Import models
const Voter = require('./models/Voter');
const Vote = require('./models/Vote');
const Party = require('./models/Party');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.json());

const PORT = process.env.PORT || 3000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/voting';

// Connect MongoDB
mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.error('❌ MongoDB connection error:', err));

// Helper to generate OTP
function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Simulated iris dataset
const irisDataset = [
  "iris_sample_01", "iris_sample_02", "iris_sample_03", "iris_sample_04", "iris_sample_05",
  "iris_sample_06", "iris_sample_07", "iris_sample_08", "iris_sample_09", "iris_sample_10"
];

// ---------------------- API ROUTES ----------------------

// Step 1: Send OTP
app.post('/api/send-otp', async (req, res) => {
  const { voterId, phone } = req.body;
  if (!voterId || !phone)
    return res.status(400).json({ error: 'Voter ID and phone required' });

  let voter = await Voter.findOne({ voterId, phone });
  if (!voter) {
    voter = new Voter({ voterId, phone });
  }

  const otp = generateOTP();
  voter.otp = otp;
  voter.otpVerified = false;
  await voter.save();

  console.log(`📱 Sending OTP ${otp} to ${phone}`);
  res.json({ message: 'OTP sent successfully' });
});

// Step 2: Verify OTP
app.post('/api/verify-otp', async (req, res) => {
  const { voterId, phone, otp } = req.body;
  const voter = await Voter.findOne({ voterId, phone });
  if (!voter) return res.status(404).json({ error: 'Voter not found' });

  if (voter.otp === otp) {
    voter.otpVerified = true;
    await voter.save();
    res.json({ message: 'OTP verified successfully' });
  } else {
    res.status(400).json({ error: 'Invalid OTP' });
  }
});

// Step 3: Iris verification
app.post('/api/verify-iris', async (req, res) => {
  const { voterId, phone, irisHash } = req.body;
  const voter = await Voter.findOne({ voterId, phone });
  if (!voter) return res.status(404).json({ error: 'Voter not found' });
  if (!voter.otpVerified) return res.status(400).json({ error: 'OTP not verified' });

  if (irisDataset.includes(irisHash)) {
    voter.irisHash = irisHash;
    await voter.save();
    res.json({ message: 'Iris verified successfully' });
  } else {
    res.status(400).json({ error: 'Iris verification failed' });
  }
});

// Step 4: Cast Vote
app.post('/api/vote', async (req, res) => {
  const { voterId, phone, party } = req.body;
  const voter = await Voter.findOne({ voterId, phone });
  if (!voter) return res.status(404).json({ error: 'Voter not found' });
  if (!voter.otpVerified || !voter.irisHash)
    return res.status(400).json({ error: 'Authentication incomplete' });
  if (voter.hasVoted)
    return res.status(400).json({ error: 'Already voted' });

  voter.hasVoted = true;
  voter.votedParty = party;
  await voter.save();

  await Vote.create({ voterId, partyChosen: party });
  console.log(`✅ Vote recorded for ${voterId}: ${party}`);

  res.json({ message: 'Vote successfully recorded' });
});

// Get all parties
app.get('/parties', async (req, res) => {
  const parties = await Party.find({});
  res.json(parties);
});

// Voter verification (simple)
app.post('/voter/verify', async (req, res) => {
  const { voterId, phone } = req.body;
  const voter = await Voter.findOne({ voterId, phone });
  if (!voter) return res.status(401).json({ error: 'Voter not found or invalid' });
  if (voter.hasVoted) return res.status(403).json({ error: 'Vote already casted' });
  res.json({ message: 'Voter verified', voterId });
});

// ---------------------- START SERVER ----------------------
app.listen(PORT, () => console.log(`🚀 Server running at http://localhost:${PORT}`));
