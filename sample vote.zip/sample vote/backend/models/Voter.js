const mongoose = require('mongoose');

const voterSchema = new mongoose.Schema({
  voterId: { type: String, required: true, unique: true },
  phone: { type: String, required: true },
  otp: { type: String, default: '' },
  otpVerified: { type: Boolean, default: false },
  irisHash: { type: String, default: '' },
  hasVoted: { type: Boolean, default: false },
  votedParty: { type: String, default: '' }
}, { timestamps: true });

module.exports = mongoose.model('Voter', voterSchema);
