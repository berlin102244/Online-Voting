const mongoose = require('mongoose');

const partySchema = new mongoose.Schema({
  name: { type: String, required: true },
  symbol: { type: String, default: '' },
  manifesto: { type: String, default: '' }
}, { timestamps: true });

module.exports = mongoose.model('Party', partySchema);
