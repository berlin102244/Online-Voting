from flask import Flask, request, jsonify
import cv2
import mediapipe as mp
import numpy as np

app = Flask(__name__)

@app.route('/enroll', methods=['POST'])
def enroll_iris():
    voter_id = request.form['voter_id']
    # Assume image file is sent as 'iris'
    iris_img = np.frombuffer(request.files['iris'].read(), np.uint8)
    img = cv2.imdecode(iris_img, cv2.IMREAD_COLOR)
    # feature extraction logic here, save to db
    # Demo: pretend enroll always succeeds
    return jsonify({'status': 'enrolled', 'voter_id': voter_id})

@app.route('/verify', methods=['POST'])
def verify_iris():
    voter_id = request.form['voter_id']
    iris_img = np.frombuffer(request.files['iris'].read(), np.uint8)
    img = cv2.imdecode(iris_img, cv2.IMREAD_COLOR)
    # feature extraction/compare against enrolled image for voter_id
    # Demo: always succeed
    return jsonify({'status': 'verified', 'voter_id': voter_id})

if __name__ == '__main__':
    app.run(port=5001)
